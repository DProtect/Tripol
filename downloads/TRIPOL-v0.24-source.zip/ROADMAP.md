# Roadmap

ORIGIN is a public-preview candidate, not stable v1.0. Goals, not promised versions or dates.

- Public release gate: sync complete source, audit history and credentials, review Apache-2.0 boundaries, Windows/Linux CI, verify downloadable assets.
- Gateway reliability: reconnect/resume, rate limits, slash interactions, Unicode and bounded queue; preserve simple API.
- Safe memory reclamation, stronger ownership/reference analysis and dynamic collections.
- Full typed control-flow TIR, register allocation, checked optimizations, broader reproducible workloads.
- Graphics, audio, crypto via reviewed APIs, database and packaging.
- Stable specification, compatibility policy, release candidates and reproducible builds before v1.0.
